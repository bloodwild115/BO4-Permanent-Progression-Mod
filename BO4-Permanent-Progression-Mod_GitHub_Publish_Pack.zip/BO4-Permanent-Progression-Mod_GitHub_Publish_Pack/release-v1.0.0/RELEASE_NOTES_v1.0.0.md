# Permanent Progression v1.0.0

The first stable standalone release of Permanent Progression for Black Ops 4 Zombies.

## Highlights

- Persistent Permanent Upgrade progression
- Key and Sentinel mastery economy
- Standalone Zombies lobby integration
- Standalone Loadout Mastery support
- Weapon-specific Performance camo balancing
- Lifetime-stat Armory camo progress
- Scaled Technical camo challenges
- Drag-and-drop Shield Client installation

## Installation

Download `PermanentProgression-v1.0.0.zip`, extract it, and place the included `PermanentProgression` folder into:

```text
C:\Call of Duty Black Ops 4\project-bo4\mods\
```

No Python or compiler is required.

## BO4 Enhancement

BO4 Enhancement compatibility is not included in this release. Enhancement-dependent upgrade trees are hidden in standalone v1.0.0. A separate optional compatibility release may be developed later.
